
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.stream.Collectors;


 
public class Main {
 
    public static void main(String[] args) {
 
        List<Estudiante> estudiantes = List.of(
                new Estudiante("Ana", "Ingeniería", 4.8),
                new Estudiante("Carlos", "Ingeniería", 3.2),
                new Estudiante("Laura", "Derecho", 4.5),
                new Estudiante("Miguel", "Medicina", 2.9),
                new Estudiante("Sofía", "Derecho", 4.9),
                new Estudiante("Andrés", "Ingeniería", 3.8),
                new Estudiante("Valentina", "Medicina", 4.2),
                new Estudiante("Daniel", "Derecho", 2.7),
                new Estudiante("Camila", "Ingeniería", 4.6),
                new Estudiante("Juan", "Medicina", 3.5)
        );
 
        // 1. Filtrar aprobados (>= 3.0)
        List<Estudiante> aprobados = estudiantes.stream()
                .filter(e -> e.getNota() >= 3.0)
                .collect(Collectors.toList());
 
        System.out.println("=== APROBADOS ===");
        aprobados.forEach(System.out::println);
 
        // 2. Ordenar por nota descendente y luego por nombre
        List<Estudiante> ordenados = estudiantes.stream()
                .sorted(
                        Comparator.comparingDouble(Estudiante::getNota)
                                .reversed()
                                .thenComparing(Estudiante::getNombre)
                )
                .collect(Collectors.toList());
 
        System.out.println("\n=== ORDENADOS ===");
        ordenados.forEach(System.out::println);
 
        // 3. Obtener los tres mejores
        List<Estudiante> top3 = estudiantes.stream()
                .sorted(
                        Comparator.comparingDouble(Estudiante::getNota)
                                .reversed()
                )
                .limit(3)
                .collect(Collectors.toList());
 
        System.out.println("\n=== TOP 3 ===");
        top3.forEach(System.out::println);
 
        // 4. Promedio general
        OptionalDouble promedioGeneral = estudiantes.stream()
                .mapToDouble(Estudiante::getNota)
                .average();
 
        System.out.println("\nPromedio general: "
                + promedioGeneral.orElse(0.0));
 
        // 5. Agrupar por programa y calcular promedio por grupo
        Map<String, Double> promedioPorPrograma =
                estudiantes.stream()
                        .collect(Collectors.groupingBy(
                                Estudiante::getPrograma,
                                Collectors.averagingDouble(
                                        Estudiante::getNota)
                        ));
 
        System.out.println("\n=== PROMEDIO POR PROGRAMA ===");
        promedioPorPrograma.forEach(
                (programa, promedio) ->
                        System.out.println(programa + " -> " + promedio)
        );
 
        // 6. Particionar aprobados y reprobados
        Map<Boolean, List<Estudiante>> particion =
                estudiantes.stream()
                        .collect(Collectors.partitioningBy(
                                e -> e.getNota() >= 3.0
                        ));
 
        System.out.println("\n=== APROBADOS ===");
        particion.get(true).forEach(System.out::println);
 
        System.out.println("\n=== REPROBADOS ===");
        particion.get(false).forEach(System.out::println);
 
        // 7. Map nombre -> nota sin claves repetidas
        Map<String, Double> nombreNota =
                estudiantes.stream()
                        .collect(Collectors.toMap(
                                Estudiante::getNombre,
                                Estudiante::getNota
                        ));
 
        System.out.println("\n=== MAP NOMBRE -> NOTA ===");
        nombreNota.forEach(
                (nombre, nota) ->
                        System.out.println(nombre + " -> " + nota)
        );
    }
}
 
class Estudiante {
    private String nombre;
    private String programa;
    private double nota;
 
    public Estudiante(String nombre, String programa, double nota) {
        this.nombre = nombre;
        this.programa = programa;
        this.nota = nota;
    }
 
    public String getNombre() {
        return nombre;
    }
 
    public String getPrograma() {
        return programa;
    }
 
    public double getNota() {
        return nota;
    }
 
    @Override
    public String toString() {
        return nombre + " | " + programa + " | " + nota;
    }
}